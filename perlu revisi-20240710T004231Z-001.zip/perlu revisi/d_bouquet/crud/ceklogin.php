<IDOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Form</title>
<!-- Bootstrap 4 CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
body {
display: flex;
align-items: center;
justify-content: center;
height: 100vh;
background-color: #f7f7f7;
}
login-container {
width: 100%;
max-width: 400px;
padding: 15px;
box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
background-color: white;
border-radius: 8px;
}
</style>
</head>
<body>