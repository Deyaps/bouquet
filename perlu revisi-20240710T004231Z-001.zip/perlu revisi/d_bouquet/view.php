<?php
include "connect.php";
include "helper.php";
include "layout/header.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = $conn->prepare("SELECT * FROM produk WHERE id = ?");
    $query->execute([$id]);
    $data = $query->fetch();
} else {
    echo "Product ID not specified.";
    exit;
}
?>

<section id="navbar" class="navbar">
  <nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light">
    <div class="container">
      <a class="navbar-brand" href="#">
        <img src="crud/img/logoo.png" width="30" height="30" class="d-inline-block align-top" alt="">
        D'BOUQUET &reg;
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php#beranda">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="index.php#galeri">Galeri</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="crud/login.php">Login</a> <!-- Link ke halaman login -->
          </li>
        </ul>
      </div>
    </div>
  </nav>
</section>

<div class="container mt-5 pt-5">
  <div class="row">
    <div class="col-md-6">
      <img src="crud/img/<?php echo $data['gambar']; ?>" class="img-fluid" alt="<?php echo $data['nama_produk']; ?>">
    </div>
    <div class="col-md-6">
      <h2><?php echo $data['nama_produk']; ?></h2>
      <p class="text-muted">Price: <?php echo $data['harga']; ?></p>
      <p>Status: <?php echo $data['status']; ?></p>
      <p><?php echo $data['deskripsi']; ?></p>
      <a href="https://wa.me/<?=$nomor_wa?>/?text=Hallo%20saya%20mau%20pesan%20bouquet%20<?=$data['nama_produk'] ?>" class="btn btn-primary">Check out</a>
    </div>
  </div>
</div>

<footer class="footer bg-dark text-white pt-5 pb-4 mt-5">
  <div class="container text-center text-md-left">
    <div class="row text-center text-md-left">
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
        <h5 class="text-uppercase mb-4 font-weight-bold text-warning">D'bouquet</h5>
        <p>Jl. Dr. Sumeru No 21G Kel. Kebon Kalapa<br>Bogor Tengah, Kota Bogor</p>
      </div>
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
        <h5 class="text-uppercase mb-4 font-weight-bold text-warning">Contact</h5>
        <p><a href="https://wa.me/<?=$nomor_wa?>/?text=Hallo%20saya%20mau%20konsultasi%20<? ?>" class="text-white"><i class="fas fa-phone mr-3"></i> +62 856 9413 9565</a></p>
        <p><a href="mailto:deap8862@gmail.com?subject=Konsultasi%20Produk&body=Hallo%20saya%20mau%20konsultasi" class="text-white"><i class="fas fa-envelope mr-3"></i> deap8862@gmail.com</a></p>
      </div>
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
        <h5 class="text-uppercase mb-4 font-weight-bold text-warning">Follow Us</h5>
        <a href="https://www.instagram.com/deyaps_/" class="btn btn-outline-light btn-floating m-1"><i class="fab fa-twitter"></i></a>
        <a href="https://www.instagram.com/deyaps_/" class="btn btn-outline-light btn-floating m-1"><i class="fab fa-facebook-f"></i></a>
        <a href="https://www.instagram.com/deyaps_/" class="btn btn-outline-light btn-floating m-1"><i class="fab fa-instagram"></i></a>
        <a href="https://www.instagram.com/deyaps_/" class="btn btn-outline-light btn-floating m-1"><i class="fab fa-linkedin-in"></i></a>
      </div>
    </div>
    <hr class="mb-4">
    <div class="row align-items-center">
      <div class="col-md-7 col-lg-12">
        <p class="text-center text-md-center">© 2024 D'bouquet. All rights reserved.</p>
      </div>
    </div>
  </div>
</footer>

<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

<?php
include "layout/footer.php";
?>
