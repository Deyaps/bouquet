<?php
include "connect.php";
include "helper.php";
include "layout/header.php";
?>

<section id="navbar" class="navbar">
  <nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light">
    <div class="container">
    <a class="navbar-brand" href="#">
        <img src="crud/img/logoo.png" width="30" height="30" class="d-inline-block align-top" alt="">
        D'BOUQUET &reg;
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="#beranda">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#galeri">Galeri</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="crud/login.php">Login</a> <!-- Link ke halaman login -->
          </li>
        </ul>
      </div>
    </div>
  </nav>
</section>


    <div class="jumbotron text-center text-white" style="background-image: url('crud/img/NAVBAR.jpg'); background-size: cover; background-position: center center;">
    <p class="lead">WELCOME TO</p>
    <h1 class="display-6">D'BOUQUET</h1>
    <p class="lead">Indonesia</p>
    <hr class="my-4">
    <p>"Where Elegance Blooms with Every Petal"</p>
</div>
    

    <section id="tentang" class="tentang">
  <div class="container">
    <div class="row">
      <div class="col text-center p-4">
        <h2>All About D'bouquet</h2>
      </div>
    </div>

    <div class="row justify-content-center mb-5">
      <div class="col">
        <img src="crud/img/21.jpg" width="500" height="500">
      </div>

      <div class="col text-justify">
        <p>Selamat datang di D'bouquet, rumah bagi keindahan yang terwujud dalam setiap rangkaian bunga. Di D'bouquet, kami tidak sekadar membuat karangan bunga biasa; kami menciptakan karya seni yang memukau dari setiap petalnya. Setiap rangkaian bunga yang kami buat adalah sebuah cerita, ditata dengan teliti untuk menghadirkan kesan yang tak terlupakan dalam setiap momen berharga Anda.</p>

        <p>Kami menghadirkan berbagai pilihan bunga segar terbaik dari kebun-kebun terpercaya, dirangkai dengan keahlian tinggi untuk memenuhi setiap kebutuhan dan selera Anda. Dengan sentuhan kreatif kami, setiap rangkaian bunga di D'bouquet tidak hanya sebagai hadiah, tetapi juga sebagai ungkapan dari hati yang tulus.</p>

        <p>Temukan keindahan yang abadi dalam setiap kelopak bunga di D'bouquet. Jadikan momen istimewa Anda lebih berarti dengan sentuhan elegan dari rangkaian bunga kami. Selamat berbelanja di D'bouquet, tempat di mana keindahan bertemu dengan keanggunan.</p>
      </div>
    </div>
  </div>
</section>


    <section id="galeri" class="galeri bg-light pb-4">
    <div class="container">
      <div class="row mb-4 pt-4">
        <div class="col text-center">
          <h2>BOUQUET PRODUCT</h2>
        </div>
      </div>

    <div class="row text-center mb-4">
      <?php
        $query=$conn->prepare("SELECT * FROM produk order by id desc");
        $query->execute();
        while($data=$query->fetch()){?>

    
<div class="col-md-3 md-3">
          <div class="card">
            <img src="crud/img/<?php echo $data['gambar'] ?>" width="250" height="350">
            <div class="card-body">
              <h3 class="card-title"><?php echo $data['nama_produk'] ?></h3>
              <p class="card-text"><?php echo $data['harga'] ?></p>
              <a href="https://wa.me/<?=$nomor_wa?>/?text=Hallo%20saya%20mau%20pesan%20bouquet%20<?=$data['nama_produk'] ?>" class="btn btn-primary">Check out</a>
              <a href="view.php?id=<?php echo $data['id']; ?>" class="btn btn-secondary">View</a>
            </div>
          </div>
        </div>
        
      <?php } ?>
    </div>
</section>


<footer class="footer bg-dark text-white pt-5 pb-4">
  <div class="container text-center text-md-left">
    <div class="row text-center text-md-left">
      <!-- About Section -->
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
        <h5 class="text-uppercase mb-4 font-weight-bold text-warning">D'bouquet</h5>
        <p>
          Jl. Dr. Sumeru No 21G Kel. Kebon Kalapa<br>
          Bogor Tengah, Kota Bogor
        </p>
      </div>

      <!-- Contact Section -->
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
        <h5 class="text-uppercase mb-4 font-weight-bold text-warning">Contact</h5>
        <p>
          <a href="https://wa.me/<?=$nomor_wa?>/?text=Hallo%20saya%20mau%20konsultasi%20<? ?>" class="text-white">
            <i class="fas fa-phone mr-3"></i> +62 856 9413 9565
          </a>
        </p>
        <p>
          <a href="mailto:deap8862@gmail.com?subject=Konsultasi%20Produk&body=Hallo%20saya%20mau%20konsultasi" class="text-white">
            <i class="fas fa-envelope mr-3"></i> deap8862@gmail.com
          </a>
        </p>
      </div>

      <!-- Social Section -->
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
        <h5 class="text-uppercase mb-4 font-weight-bold text-warning">Follow Us</h5>
        <a href="https://www.instagram.com/deyaps_/" class="btn btn-outline-light btn-floating m-1">
          <i class="fab fa-twitter"></i>
        </a>
        <a href="https://www.instagram.com/deyaps_/" class="btn btn-outline-light btn-floating m-1">
          <i class="fab fa-facebook-f"></i>
        </a>
        <a href="https://www.instagram.com/deyaps_/" class="btn btn-outline-light btn-floating m-1">
          <i class="fab fa-instagram"></i>
        </a>
        <a href="https://www.instagram.com/deyaps_/" class="btn btn-outline-light btn-floating m-1">
          <i class="fab fa-linkedin-in"></i>
        </a>
      </div>
    </div>

    <hr class="mb-4">

    <!-- Copyright -->
    <div class="row align-items-center">
      <div class="col-md-7 col-lg-12">
        <p class="text-center text-md-center">© 2024 D'bouquet. All rights reserved.</p>
      </div>
    </div>
  </div>
</footer>

<!-- Add Font Awesome for icons -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>



    

</footer>

    </section><!-- /Contact Section -->
  <?php
  include "layout/footer.php";
  ?>